package com.green.todo.board.model.req;

import lombok.Data;

@Data
public class GetBoardReq {
    private Long userId;
}
